Hello!  This is a copy of the famous vim editor compiled as a native
android binary from a mercurial download on 20 August 2010.

Visit this link to see how I got it to compile:
http://credentiality2.blogspot.com/2010/08/native-vim-for-android.html

Happy hacking!
