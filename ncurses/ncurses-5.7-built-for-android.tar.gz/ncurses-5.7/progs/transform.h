#define PROG_CAPTOINFO "captoinfo"
#define PROG_INFOTOCAP "infotocap"
#define PROG_RESET     "reset"
#define PROG_INIT      "init"
